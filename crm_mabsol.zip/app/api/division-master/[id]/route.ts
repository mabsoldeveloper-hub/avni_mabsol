import { NextRequest, NextResponse } from "next/server";
import connectDB from "@/lib/mongodb";
import Division from "@/models/Division";

// ==============================
// GET Division By ID
// ==============================
export async function GET(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    await connectDB();
    const { id } = await params;

    const division = await Division.findById(id);

    if (!division) {
      return NextResponse.json(
        {
          success: false,
          message: "Division not found.",
        },
        { status: 404 }
      );
    }

    return NextResponse.json({
      success: true,
      data: division,
    });
  } catch (error: any) {
    return NextResponse.json(
      {
        success: false,
        message: error.message || "Error fetching division",
      },
      { status: 500 }
    );
  }
}

// ==============================
// UPDATE Division
// ==============================
export async function PUT(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    await connectDB();
    const { id } = await params;

    const body = await req.json();

    const {
      companyCode,
      companyName,
      divisionCode,
      divisionName,
      shortName,
      description,
      status,
    } = body;

    if (!companyCode || !companyName || !divisionCode || !divisionName) {
      return NextResponse.json(
        {
          success: false,
          message: "Company Code, Company Name, Division Code, and Division Name are required.",
        },
        { status: 400 }
      );
    }

    const formattedCompanyCode = companyCode.trim();
    const formattedCompanyName = companyName.trim();
    const formattedDivisionCode = divisionCode.trim().toUpperCase();
    const formattedDivisionName = divisionName.trim();

    // Duplicate Code check excluding current id
    const codeExists = await Division.findOne({
      _id: { $ne: id },
      companyCode: formattedCompanyCode,
      divisionCode: formattedDivisionCode,
    });

    if (codeExists) {
      return NextResponse.json(
        {
          success: false,
          message: `Division Code '${formattedDivisionCode}' already exists for this Company.`,
        },
        { status: 400 }
      );
    }

    // Duplicate Name check excluding current id
    const nameExists = await Division.findOne({
      _id: { $ne: id },
      companyCode: formattedCompanyCode,
      divisionName: {
        $regex: `^${formattedDivisionName}$`,
        $options: "i",
      },
    });

    if (nameExists) {
      return NextResponse.json(
        {
          success: false,
          message: `Division Name '${formattedDivisionName}' already exists for this Company.`,
        },
        { status: 400 }
      );
    }

    const division = await Division.findByIdAndUpdate(
      id,
      {
        companyCode: formattedCompanyCode,
        companyName: formattedCompanyName,
        divisionCode: formattedDivisionCode,
        divisionName: formattedDivisionName,
        shortName: shortName?.trim() || "",
        description: description?.trim() || "",
        status: status || "Active",
      },
      {
        new: true,
        runValidators: true,
      }
    );

    if (!division) {
      return NextResponse.json(
        {
          success: false,
          message: "Division not found.",
        },
        { status: 404 }
      );
    }

    return NextResponse.json({
      success: true,
      message: "Division updated successfully.",
      data: division,
    });
  } catch (error: any) {
    return NextResponse.json(
      {
        success: false,
        message: error.message || "Failed to update division",
      },
      { status: 500 }
    );
  }
}

// ==============================
// DELETE Division
// ==============================
export async function DELETE(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    await connectDB();
    const { id } = await params;

    const division = await Division.findByIdAndDelete(id);

    if (!division) {
      return NextResponse.json(
        {
          success: false,
          message: "Division not found.",
        },
        { status: 404 }
      );
    }

    return NextResponse.json({
      success: true,
      message: "Division deleted successfully.",
    });
  } catch (error: any) {
    return NextResponse.json(
      {
        success: false,
        message: error.message || "Failed to delete division",
      },
      { status: 500 }
    );
  }
}