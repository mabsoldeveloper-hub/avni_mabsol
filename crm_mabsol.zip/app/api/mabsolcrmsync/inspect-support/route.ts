import { NextResponse } from "next/server";

export async function GET() {
  return new NextResponse("Disabled", { status: 404 });
}
