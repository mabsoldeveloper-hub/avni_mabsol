"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { FaUserPlus } from "react-icons/fa";

export default function CreateUserPage() {
  const router = useRouter();

  const [loading, setLoading] = useState(false);

  const [companies, setCompanies] = useState<any[]>([]);
  const [roles, setRoles] = useState<any[]>([]);
  const [usersList, setUsersList] = useState<any[]>([]);

  const [photoPreview, setPhotoPreview] = useState("/avatar.png");

  const [form, setForm] = useState({
    employeeCode: "",
    name: "",
    email: "",
    password: "",
    mobile: "",
    companyId: "",
    roleId: "",
    department: "",
    designation: "",
    gender: "",
    dob: "",
    joiningDate: "",
    address: "",
    city: "",
    state: "",
    country: "India",
    pincode: "",
    status: "Active",
    profilePhoto: "",
    // Sales Hierarchy fields
    salesHierarchyRole: "",
    salesHierarchyReportsTo: "",
    salesHierarchyState: "",
    salesHierarchyRegion: "",
  });

  useEffect(() => {
    loadCompanies();
    loadRoles();
    loadUsers();
  }, []);

  const loadUsers = async () => {
    try {
      const res = await fetch("/api/users");
      const data = await res.json();
      if (data.success || Array.isArray(data)) {
        setUsersList(Array.isArray(data) ? data : data.users || []);
      }
    } catch (e) {
      console.log(e);
    }
  };

  const loadCompanies = async () => {
    try {
      const res = await fetch("/api/company-master");
      const data = await res.json();
      setCompanies(data);
    } catch (error) {
      console.log(error);
    }
  };

  const loadRoles = async () => {
    try {
      const res = await fetch("/api/roles");
      const data = await res.json();
      setRoles(data);
    } catch (error) {
      console.log(error);
    }
  };


  const saveUser = async () => {
    try {
      setLoading(true);

      const res = await fetch("/api/users", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(form),
      });

      const data = await res.json();

      if (!res.ok) {
        alert(data.error);
        return;
      }

      alert("User Created Successfully");
      router.push("/dashboard/users");
    } catch (error) {
      alert("Failed to Create User");
    } finally {
      setLoading(false);
    }
  };

  const inputClass =
    "w-full rounded-lg text-sm px-3 py-2 bg-white/50 border border-white/60 text-gray-700 placeholder-gray-400 outline-none focus:bg-white/70 focus:border-indigo-400/60 focus:ring-2 focus:ring-indigo-400/20 transition-all";

  const labelClass =
    "block text-xs font-medium text-gray-500 uppercase tracking-wide mb-1.5";

  return (
    <div
      className="
        relative rounded-2xl overflow-hidden
        bg-white/60 backdrop-blur-xl
        border border-white/40
        shadow-[0_4px_20px_rgba(0,0,0,0.06)]
      "
    >
      {/* top sheen */}
      <div className="pointer-events-none absolute inset-x-0 top-0 h-1/2 bg-gradient-to-b from-white/50 to-transparent" />

      {/* header */}
      <div className="relative flex items-center gap-2 px-4 py-3 bg-gradient-to-r from-indigo-500/80 to-violet-500/80 backdrop-blur-md">
        <div className="flex items-center justify-center h-7 w-7 rounded-lg bg-white/25 text-white">
          <FaUserPlus size={14} />
        </div>
        <h5 className="text-sm font-semibold text-white tracking-wide m-0">
          Create User
        </h5>
      </div>

      {/* body */}
      <div className="relative p-5">
        <div className="grid grid-cols-1 md:grid-cols-12 gap-4">
          {/* Profile Photo */}
          <div className="md:col-span-12 flex flex-col items-center gap-3">
            <img
              src={photoPreview}
              alt="Profile"
              width={110}
              height={110}
              className="rounded-full object-cover ring-4 ring-white/60 shadow-md"
            />

            <input
              type="file"
              className="text-xs text-gray-500 file:mr-3 file:py-1.5 file:px-3 file:rounded-lg file:border-0 file:text-xs file:font-medium file:bg-indigo-500/90 file:text-white hover:file:bg-indigo-500 file:cursor-pointer"
              onChange={async (e) => {
                const file = e.target.files?.[0];
                if (!file) return;

                if (file.size > 2 * 1024 * 1024) {
                  alert("Maximum file size is 2MB");
                  return;
                }

                const fd = new FormData();
                fd.append("file", file);

                const res = await fetch("/api/upload-user-photo", {
                  method: "POST",
                  body: fd,
                });

                const data = await res.json();

                if (!data.success) {
                  alert("Upload Failed");
                  return;
                }

                setPhotoPreview(data.url);

                setForm((prev) => ({
                  ...prev,
                  profilePhoto: data.url,
                }));
              }}
            />
          </div>

          {/* Employee Code */}
          <div className="md:col-span-4">
            <label className={labelClass}>Employee Code</label>
            <input
              className={inputClass}
              value={form.employeeCode}
              onChange={(e) => setForm({ ...form, employeeCode: e.target.value })}
            />
          </div>

          {/* Name */}
          <div className="md:col-span-8">
            <label className={labelClass}>Full Name</label>
            <input
              className={inputClass}
              value={form.name}
              onChange={(e) => setForm({ ...form, name: e.target.value })}
            />
          </div>

          {/* Email */}
          <div className="md:col-span-6">
            <label className={labelClass}>Email</label>
            <input
              type="email"
              className={inputClass}
              value={form.email}
              onChange={(e) => setForm({ ...form, email: e.target.value })}
            />
          </div>

          {/* Password */}
          <div className="md:col-span-6">
            <label className={labelClass}>Password</label>
            <input
              type="password"
              className={inputClass}
              value={form.password}
              onChange={(e) => setForm({ ...form, password: e.target.value })}
            />
          </div>

          {/* Mobile */}
          <div className="md:col-span-6">
            <label className={labelClass}>Mobile</label>
            <input
              className={inputClass}
              value={form.mobile}
              onChange={(e) => setForm({ ...form, mobile: e.target.value })}
            />
          </div>

          {/* Company */}
          <div className="md:col-span-6">
            <label className={labelClass}>Company</label>
            <select
              className={inputClass}
              value={form.companyId}
              onChange={(e) => setForm({ ...form, companyId: e.target.value })}
            >
              <option value="">Select Company</option>
              {companies.map((c) => (
                <option key={c._id} value={c._id}>
                  {c.companyName}
                </option>
              ))}
            </select>
          </div>

          {/* Role */}
          <div className="md:col-span-6">
            <label className={labelClass}>Role</label>
            <select
              className={inputClass}
              value={form.roleId}
              onChange={(e) => setForm({ ...form, roleId: e.target.value })}
            >
              <option value="">Select Role</option>
              {roles.map((r) => (
                <option key={r._id} value={r._id}>
                  {r.roleName}
                </option>
              ))}
            </select>
          </div>

          {/* Department */}
          <div className="md:col-span-6">
            <label className={labelClass}>Department</label>
            <input
              className={inputClass}
              value={form.department}
              onChange={(e) => setForm({ ...form, department: e.target.value })}
            />
          </div>

          {/* Designation */}
          <div className="md:col-span-6">
            <label className={labelClass}>Designation</label>
            <input
              className={inputClass}
              value={form.designation}
              onChange={(e) => setForm({ ...form, designation: e.target.value })}
            />
          </div>

          {/* Gender */}
          <div className="md:col-span-3">
            <label className={labelClass}>Gender</label>
            <select
              className={inputClass}
              value={form.gender}
              onChange={(e) => setForm({ ...form, gender: e.target.value })}
            >
              <option>Male</option>
              <option>Female</option>
              <option>Other</option>
            </select>
          </div>

          {/* DOB */}
          <div className="md:col-span-3">
            <label className={labelClass}>DOB</label>
            <input
              type="date"
              className={inputClass}
              value={form.dob}
              onChange={(e) => setForm({ ...form, dob: e.target.value })}
            />
          </div>

          {/* Joining */}
          <div className="md:col-span-3">
            <label className={labelClass}>Joining Date</label>
            <input
              type="date"
              className={inputClass}
              value={form.joiningDate}
              onChange={(e) => setForm({ ...form, joiningDate: e.target.value })}
            />
          </div>

          {/* Status */}
          <div className="md:col-span-3">
            <label className={labelClass}>Status</label>
            <select
              className={inputClass}
              value={form.status}
              onChange={(e) => setForm({ ...form, status: e.target.value })}
            >
              <option>Active</option>
              <option>Inactive</option>
            </select>
          </div>

          {/* Address */}
          <div className="md:col-span-12">
            <label className={labelClass}>Address</label>
            <textarea
              rows={3}
              className={inputClass}
              value={form.address}
              onChange={(e) => setForm({ ...form, address: e.target.value })}
            />
          </div>

          <div className="md:col-span-4">
            <label className={labelClass}>City</label>
            <input
              className={inputClass}
              value={form.city}
              onChange={(e) => setForm({ ...form, city: e.target.value })}
            />
          </div>

          <div className="md:col-span-4">
            <label className={labelClass}>State</label>
            <input
              className={inputClass}
              value={form.state}
              onChange={(e) => setForm({ ...form, state: e.target.value })}
            />
          </div>

          <div className="md:col-span-4">
            <label className={labelClass}>Pincode</label>
            <input
              className={inputClass}
              value={form.pincode}
              onChange={(e) => setForm({ ...form, pincode: e.target.value })}
            />
          </div>

          {/* ── SALES HIERARCHY SECTION ── */}
          <div className="md:col-span-12 mt-4 pt-4 border-t border-indigo-200/80">
            <div className="flex items-center gap-2 mb-3">
              <span className="px-2.5 py-1 rounded-md bg-indigo-500/10 text-indigo-700 font-bold text-xs">
                🌲 Sales Hierarchy Setup
              </span>
              <span className="text-xs text-gray-400">
                (ZSM → RSM → M.R. / S.R.)
              </span>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-12 gap-4">
              <div className="md:col-span-6">
                <label className={labelClass}>Sales Hierarchy Role</label>
                <select
                  className={inputClass}
                  value={form.salesHierarchyRole}
                  onChange={(e) => setForm({ ...form, salesHierarchyRole: e.target.value })}
                >
                  <option value="">None / Not Assigned</option>
                  <option value="ZSM">ZSM (Zonal Sales Manager)</option>
                  <option value="RSM">RSM (Regional Sales Manager)</option>
                  <option value="MR">M.R. / S.R. (Sales Representative)</option>
                </select>
              </div>

              <div className="md:col-span-6">
                <label className={labelClass}>Reports To (Parent Manager)</label>
                <select
                  className={inputClass}
                  value={form.salesHierarchyReportsTo}
                  onChange={(e) => setForm({ ...form, salesHierarchyReportsTo: e.target.value })}
                >
                  <option value="">None (Top Executive)</option>
                  {usersList.map((u) => (
                    <option key={u._id} value={u._id}>
                      {u.name} {u.employeeCode ? `(${u.employeeCode})` : ""} - {u.designation || "Executive"}
                    </option>
                  ))}
                </select>
              </div>

              <div className="md:col-span-6">
                <label className={labelClass}>State / Zone</label>
                <input
                  className={inputClass}
                  value={form.salesHierarchyState}
                  onChange={(e) => setForm({ ...form, salesHierarchyState: e.target.value })}
                  placeholder="e.g. Uttar Pradesh"
                />
              </div>

              <div className="md:col-span-6">
                <label className={labelClass}>Region / Territory</label>
                <input
                  className={inputClass}
                  value={form.salesHierarchyRegion}
                  onChange={(e) => setForm({ ...form, salesHierarchyRegion: e.target.value })}
                  placeholder="e.g. Lucknow Region"
                />
              </div>
            </div>
          </div>
        </div>


        {/* Actions */}
        <div className="mt-6 flex items-center gap-3 border-t border-gray-200/70 pt-4">
          <button
            className="px-4 py-2 rounded-lg text-sm font-medium text-white bg-indigo-500/90 hover:bg-indigo-500 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
            onClick={saveUser}
            disabled={loading}
          >
            {loading ? "Saving..." : "Create User"}
          </button>

          <button
            className="px-4 py-2 rounded-lg text-sm font-medium text-gray-600 bg-white/50 hover:bg-white/70 border border-white/60 transition-colors"
            onClick={() => router.push("/dashboard/users")}
          >
            Back
          </button>
        </div>
      </div>
    </div>
  );
}